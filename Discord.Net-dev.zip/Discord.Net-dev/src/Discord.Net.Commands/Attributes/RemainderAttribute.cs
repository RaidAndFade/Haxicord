﻿using System;

namespace Discord.Commands
{
    [AttributeUsage(AttributeTargets.Parameter)]
    public class RemainderAttribute : Attribute
    {
    }
}
