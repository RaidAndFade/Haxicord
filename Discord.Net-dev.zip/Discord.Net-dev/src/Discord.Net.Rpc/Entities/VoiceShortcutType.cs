﻿namespace Discord.Rpc
{
    public enum VoiceShortcutType
    {
        KeyboardKey = 0,
        MouseButton = 1,
        KeyboardModifierKey = 2,
        GamepadButton = 3
    }
}
