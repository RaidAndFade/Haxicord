﻿namespace Discord.Rpc
{
    public enum RpcGuildEvent
    {
        GuildStatus
    }
}
