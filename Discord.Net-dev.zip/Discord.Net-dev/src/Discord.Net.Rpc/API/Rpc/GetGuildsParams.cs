﻿#pragma warning disable CS1591

namespace Discord.API.Rpc
{
    internal class GetGuildsParams
    {
    }
}
