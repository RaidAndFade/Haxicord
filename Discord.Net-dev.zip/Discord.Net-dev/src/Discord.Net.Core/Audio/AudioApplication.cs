namespace Discord.Audio
{
    public enum AudioApplication : int
    {
        Voice,
        Music,
        Mixed
    }
}