﻿namespace Discord
{
    public enum TokenType
    {
        User,
        Bearer,
        Bot,
        Webhook
    }
}
