﻿namespace Discord
{
    public enum StreamType
    {
        NotStreaming = 0,
        Twitch = 1
    }
}
