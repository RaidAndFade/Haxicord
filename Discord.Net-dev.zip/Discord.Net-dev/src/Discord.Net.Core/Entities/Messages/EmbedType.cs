﻿namespace Discord
{
    public enum EmbedType
    {
        Rich,
        Link,
        Video,
        Image,
        Gifv,
        Article,
        Tweet
    }
}
