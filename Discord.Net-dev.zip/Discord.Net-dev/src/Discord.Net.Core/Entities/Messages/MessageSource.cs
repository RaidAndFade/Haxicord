namespace Discord
{
    public enum MessageSource
    {
        System,
        User,
        Bot,
        Webhook
    }
}
