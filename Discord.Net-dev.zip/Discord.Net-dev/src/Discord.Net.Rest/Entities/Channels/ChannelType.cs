﻿namespace Discord
{
    public enum ChannelType
    {
        Text = 0,
        DM = 1,
        Voice = 2,
        Group = 3
    }
}
