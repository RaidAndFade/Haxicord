
# API Documentation

This is where you will find documentation for all members and objects in Discord.Net

__Commonly Used Entities__  

* @Discord.WebSocket  
* @Discord.WebSocket.DiscordSocketClient  
* @Discord.WebSocket.SocketGuildChannel  
* @Discord.WebSocket.SocketGuildUser  
* @Discord.WebSocket.SocketMessage  
* @Discord.WebSocket.SocketRole  